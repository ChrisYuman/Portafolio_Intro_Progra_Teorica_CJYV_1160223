﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clase_Repetitivas_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Pablo Andres Bocel Morales 1109623, Christopher Javier Yuman Valdez 1160223
            int cont = 0;
            int cont1 = 0;
            int cont2 = 0;
            int cont3 = 0;
            int cont4 = 0;
            int cent = 0; int cent1 = 0; int cent2 = 0; int cent3 = 0; int cent4 = 0; int error = 0;
            double bill= 0;
            char resp;
            double total = 0;
            

            do
            {
                Console.Clear();
                try
                {
                    Console.WriteLine("Ingrese el billete o moneda");
                    bill = Convert.ToDouble(Console.ReadLine());
                }
                catch 
                {
                    Console.WriteLine("Dato no válido");
                }
                    Console.WriteLine("Desea ingresar mas billetes? s=si n=no");
                    resp = Convert.ToChar(Console.ReadLine());
                    
                        if (bill == 5)
                        {
                            total += bill;
                            cont++;
                            
                        }
                        if (bill == 10)
                        {
                            total += bill;
                            cont1++;
                            
                        }
                        if (bill == 20)
                        {
                            total += bill;
                            cont2++;
                        }
                        if (bill == 50)
                        {
                            total += bill;
                            cont3++;
                        }
                        if (bill == 100)
                        {
                            total += bill;
                            cont4++;
                        }
                        if (bill == 0.05)
                        {
                            total += bill;
                            cent++;
                        }
                        if (bill == 0.10)
                        {
                            total += bill;
                            cent1++;
                        }
                        if (bill == 0.25)
                        {
                            total += bill;
                            cent2++;
                        }
                        if (bill == 0.50)
                        {
                            total += bill;
                            cent3++;
                        }
                        if (bill == 1)
                        {
                            total += bill;
                            cent4++;
                        }
                        else
                        {
                            error++;
                        }
                
            }
            while (resp == 's');
            Console.WriteLine($"La cantidad de monedas de 0.05 es de {cent}");
            Console.WriteLine($"La cantidad de monedas de 0.10 es de {cent1}");
            Console.WriteLine($"La cantidad de monedas de 0.25 es de {cent2}");
            Console.WriteLine($"La cantidad de monedas de 0.50 es de {cent3}");
            Console.WriteLine($"La cantidad de monedas de 1 es de {cent4}");
            Console.WriteLine($"La cantidad de billetes de 5 es de {cont}");
            Console.WriteLine($"La cantidad de billetes de 10 es de {cont1}");
            Console.WriteLine($"La cantidad de billetes de 20 es de {cont2}");
            Console.WriteLine($"La cantidad de billetes de 50 es de {cont3}");
            Console.WriteLine($"La cantidad de billetes de 100 es de {cont4}");
            Console.WriteLine($"La cantidad total de la caja es de {total}");

            Console.ReadKey();
        }
    }
}
