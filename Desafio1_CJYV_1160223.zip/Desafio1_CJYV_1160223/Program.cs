﻿public class libro
{
    public int CodigoIdentifacion { get; private set; }
    public string Nombre { get; private set; }
    public int CantidadPag { get; private set; }

    public int PaginasDisponibles { get; private set; }

    public int PaginasLeidas { get; private set; }


    public libro(int codigoIdentificacion, string nombre, int cantidadPag)
    {
        CodigoIdentifacion = codigoIdentificacion;
        Nombre = nombre;
        CantidadPag = cantidadPag;
        PaginasDisponibles = 0;
    }

    public void PaginasLibro()
    {
        PaginasDisponibles = CantidadPag;
        PaginasLeidas = 0;
    }

    public void leerPaginas(int paginas)
    {
        if (paginas <= PaginasDisponibles)
        {
            PaginasDisponibles -= paginas;
            PaginasLeidas += paginas;
            ;
        }
        else
        {
            Console.WriteLine("el libro ya fue leido");
        }
    }
    public double ObtenerPorcentajeLectura()
    {
        double calcularportantaje = (double)PaginasLeidas / CantidadPag * 100;
        return calcularportantaje;
    }
    public Boolean Leido()
    {
        Boolean esLibro = false;
        if (PaginasLeidas == CantidadPag)
        {
            esLibro = true;
        }
        return esLibro;
    }

    public void MostrarLibro()
    {
        Console.WriteLine("Codigo del libro: " + CodigoIdentifacion);
        Console.WriteLine("Nombre del libro " + Nombre);
        Console.WriteLine("Cantidad de paginas " + CantidadPag);
        Console.WriteLine("Porcentaje de lectura: " + ObtenerPorcentajeLectura() + "%");
        Console.WriteLine("Paginas leidas " + (CantidadPag - PaginasDisponibles));
        
    }

    static void Main()
    {
        Console.WriteLine("Ingrese codigo del libro");
        int codigol = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese nombre del libro ");
        string nombrel = (Console.ReadLine());
        Console.WriteLine("Ingrese el numero de paginas del libro");
        int numeropag = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese el numero de paginas leidas");
        int pag = Convert.ToInt32(Console.ReadLine());
        libro miLibro = new libro(codigol, nombrel, numeropag);
        char opcion;
        miLibro.PaginasLibro();
        miLibro.leerPaginas(pag);
        miLibro.MostrarLibro();
        if (miLibro.Leido())
        {
            Console.WriteLine("El libro " + miLibro.Nombre + " Esta leido");
        }
        else
        {
            Console.WriteLine("El libro " + miLibro.Nombre + " No esta leido");
        }
        Console.ReadKey();
    }

}