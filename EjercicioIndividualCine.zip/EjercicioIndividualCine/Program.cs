﻿public class pelicula
{
    public string Nombre { get; private set; }
    public double Duracion { get; private set; }
    public string Genero { get; private set; }
    public int Año { get; private set; }

    public double Calificacion { get; private set; }

    public string Valoracion { get; private set; }

    public pelicula(string nombre, double duracion, string genero, int año, double calificacion)
    {
        Nombre = nombre;
        Duracion = duracion;
        Genero = genero;
        Calificacion = calificacion;
        Año = año;
    }

    public void MostrarDatosPelicula( )
    {
        Console.WriteLine("Nombre de la pelicula: " + Nombre);
        Console.WriteLine("Duracion de la pelicula: " + Duracion);
        Console.WriteLine("Genero de la pelicula: " + Genero);
        Console.WriteLine("Calificacion de la pelicula: " + Calificacion);
        Console.WriteLine("Año de la pelicula: " + Año);
    }

    public Boolean esPeliculaEpica() 
    {
        Boolean esPelicula = false;
        if (Duracion >= 180)
        {
            esPelicula = true;
        }
        return esPelicula;
    }

    public Boolean esSimiliar(pelicula datosdepelicula)
    {
        Boolean esSimiliarr = false;
        if (Genero == datosdepelicula.Genero && Valoracion == datosdepelicula.Valoracion)
        {
            esSimiliarr = true;
        }
        return esSimiliarr;
    }

    public void esValoracion()
    {
        if (Calificacion >= 0 && Calificacion <= 2)
        {
            Valoracion = "muy mala";
        }else if (Calificacion > 2 && Calificacion <= 5)
        {
            Valoracion = "mala";
        }else if (Calificacion > 5 && Calificacion <= 7)
        {
            Valoracion = "regular";
        }else if (Calificacion > 7 && Calificacion <= 8)
        {
            Valoracion = "buena";
        }else if (Calificacion > 8 && Calificacion <= 10)
        {
            Valoracion = "excelente";
        }
        
    }

    static void Main()
    {

        string nombre = "";
        double duracion = 0;
        string genero = "";
        int año = 0;
        double clasificacion =0;

        Console.WriteLine("Ingrese los datos de la pelicula 1");
        Console.WriteLine("Ingrese el nombre de la pelicula");
        nombre = (Console.ReadLine());
        Console.WriteLine("Ingrese la duracion de la pelicula en minutos");
        duracion = Convert.ToDouble(Console.ReadLine());
        genero = "";
        do
        {
            Console.WriteLine("Ingrese el genero de la pelicula (Acción, Comedia, Drama, Suspenso");
            genero = (Console.ReadLine());

        } while (!(genero.ToLower() == "acción" || genero.ToLower() == "comedia" || genero.ToLower() == "drama" || genero.ToLower() == "suspendo"));
        Console.WriteLine("Ingrese el año de la pelicula");
        año = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese la clasificacion de la pelicula");
        clasificacion = Convert.ToDouble(Console.ReadLine());

        pelicula pelicula1 = new pelicula(nombre, duracion, genero, año, clasificacion);

        Console.WriteLine("Ingrese los datos de la pelicula 2");
        Console.WriteLine("Ingrese el nombre de la pelicula");
        nombre = (Console.ReadLine());
        Console.WriteLine("Ingrese la duracion de la pelicula en minutos");
        duracion = Convert.ToDouble(Console.ReadLine());
        genero = "";
        do
        {
            Console.WriteLine("Ingrese el genero de la pelicula (Acción, Comedia, Drama, Suspenso");
            genero = (Console.ReadLine());

        } while (!(genero.ToLower() == "acción" || genero.ToLower() == "comedia" || genero.ToLower() == "drama" || genero.ToLower() == "suspenso"));
        Console.WriteLine("Ingrese el año de la pelicula");
        año = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Ingrese la clasificacion de la pelicula");
        clasificacion = Convert.ToDouble(Console.ReadLine());

        pelicula pelicula2 = new pelicula(nombre, duracion, genero, año, clasificacion);

        string opcion = "";
        do
        {
            
           Console.Clear();
           Console.WriteLine("Menu");
            Console.WriteLine("opcion 1) Ver datos de pelicula 1");
            Console.WriteLine("opcion 2) Ver datos de pelicula 2");
            Console.WriteLine("opcion 3) Validar si la pelicula 1 es epica");
            Console.WriteLine("opcion 4) Validar si la pelicula 2 es epica");
            Console.WriteLine("opcion 5) Valoraciòn de la pelicula 1");
            Console.WriteLine("opcion 6) Valoraciòn de la pelicula 2");
            Console.WriteLine("opcion 7) Validar si la pelicula 1 vs pelicula 2 son similares");
            Console.WriteLine("opcion 8) salir");
            opcion = (Console.ReadLine());

            switch (opcion)
            {
                case "1":
                pelicula1.MostrarDatosPelicula();
                    break;
               case "2":
                pelicula2.MostrarDatosPelicula();
            break;
               case "3":
                    if (pelicula1.esPeliculaEpica())
                    {
                        Console.WriteLine("La pelicula "+pelicula1.Nombre+" es epica");
                    }
                    else
                    {
                        Console.WriteLine("La pelicula " + pelicula1.Nombre + " no es epica");
                    }
                    break;
               case "4":
                    if (pelicula2.esPeliculaEpica())
                    {
                        Console.WriteLine("La pelicula " + pelicula2.Nombre + " es epica");
                    }
                    else
                    {
                        Console.WriteLine("La pelicula " + pelicula2.Nombre + " no es epica");
                    }
                    break;
               case "5":
                    pelicula1.esValoracion();
                    Console.WriteLine("La valoracion de la pelicula es:" + pelicula1.Valoracion);
                    break;
               case "6":
                    pelicula2.esValoracion();
                    Console.WriteLine("La valoracion de la pelicula es:" + pelicula2.Valoracion);
                    break;
                case "7":
                    if (pelicula1.esSimiliar(pelicula2))
                    {
                        Console.WriteLine("La pelicula 1 es similar a la pelicula 2");
                    }
                    else
                    {
                        Console.WriteLine("La pelicula 1 no es similar a la pelicula 2");
                    }
                    break;
            }
                Console.ReadKey();

    } while (opcion != "8");




    }









}