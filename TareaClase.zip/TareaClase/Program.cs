﻿using System;

class Program
{
    static void Main()
    {


        double[,] notas3 = new double[5, 6];
        string[] nombres2 = new string[5];

        for (int f = 0; f < 5; f++)
        {
            Console.WriteLine("Ingrese nombre");
            nombres2[f] = Console.ReadLine();

            for (int c = 0; c < 6; c++)
            {
                Random r = new Random();
                notas3[f, c] = r.Next(1, 100);
            }
        }


        double[] promedioest = new double[5];
        for (int f = 0; f < 5; f++)
        {
            double promedio = 0;
            for (int c = 0; c < 6; c++)
            {
                promedio = promedio + notas3[f, c];
            }
            promedio = promedio / 6;
            promedioest[f] = promedio;
        }

        for (int f = 0; f < 5; f++)
        {
            Console.Write(nombres2[f] + " ");
            for (int c = 0; c < 6; c++)
            {
                Console.Write(notas3[f, c] + " - ");
            }
            Console.Write("Promedio es: " + promedioest[f]);
            Console.WriteLine();

        }

    }
}