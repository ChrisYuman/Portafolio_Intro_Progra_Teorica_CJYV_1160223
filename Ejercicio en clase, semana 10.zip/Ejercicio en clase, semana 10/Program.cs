﻿public class cafetera
{
    public string CodiInventario { get; private set; }
    public int CapacidadTazas { get; private set; }
    public int TazasDisponibles { get; private set; }
    public int TazasServidad { get; private set; }

    public  cafetera(string codiInventario,  int capacidadTazas)
    {
        CodiInventario = codiInventario;
        CapacidadTazas = capacidadTazas;
        TazasDisponibles = 0;
        TazasServidad = 0;
    }

    public void HacerCafe()
    {
        TazasDisponibles = CapacidadTazas;
        TazasServidad = 0;
    }

    public void ServirTaza(int tazas)
    {
        if (tazas <= TazasDisponibles)
        {
            TazasDisponibles -= tazas;
            TazasServidad += tazas;
            ;
        }
        else
        {
            Console.WriteLine("No tenemos suficientes tazas disponibles");
        }
    }
    public double ObtenerPorcentajeDisponibilidad()
    {
        double calcularportantaje= (double) TazasDisponibles / CapacidadTazas * 100;
        return calcularportantaje;
    }

    public void MostrarEstado()
    {
        Console.WriteLine("Codigo de inventario: " +CodiInventario);
        Console.WriteLine("Capacidad en cantidad de tazas: " + CapacidadTazas);
        Console.WriteLine("Porcentaje de disponibilidad: " + ObtenerPorcentajeDisponibilidad() + "%");
        Console.WriteLine("Tazas servidad: " + (CapacidadTazas - TazasDisponibles));
    }

    static void Main()
    {
        Console.WriteLine("Ingrese capacidad de cafetera");
        int cap = Convert.ToInt32(Console.ReadLine());
        cafetera miCafetera = new cafetera("1", cap);
        char opcion;
        miCafetera.HacerCafe();
        do
        {
            Console.WriteLine("Ingrese el numero de tazas");
            int tz = Convert.ToInt32(Console.ReadLine());
            miCafetera.ServirTaza(tz);
            miCafetera.MostrarEstado();

            Console.WriteLine("Desea ingresar mas tazas? s/n");
            opcion = Convert.ToChar(Console.ReadLine().ToLower()); 
        } while(opcion == 's');
        


        Console.ReadKey();
    }

}