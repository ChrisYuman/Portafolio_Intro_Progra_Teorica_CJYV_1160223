﻿using System;

class Program
{
    static void Main()
    {

        double numero = 0;
        double promedio = 0;
        double suma = 0;
        double cont = 0;
       
        while (cont <= 9) 
        {
            Console.WriteLine("Ingrese un numero");
            numero = Convert.ToDouble(Console.ReadLine());

            if (numero > 0 )
            {
                suma = suma + numero;
                cont++;
                
            }
            else
            {
                Console.WriteLine("Ingrese un numero mayor a 0");

            }
            
        }
        promedio = suma / 10;
        Console.WriteLine("El promedio es:" + promedio);
        Console.ReadLine();
    }
}