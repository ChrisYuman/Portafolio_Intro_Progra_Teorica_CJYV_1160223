﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EjercicioenClaseVectores
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] temp = new double [2, 7];
            Random r = new Random();
            for (int f = 0; f < 2; f++)
            {
                
                for (int c = 0; c < 7; c++)
                {
                    temp[f, c] = r.Next(1, 60);
                }
            }
            for (int f = 0; f < 2; ++f)
            {
                
                for (int c = 0; c < 7; c++)
                {
                    Console.Write(temp[f, c] + " - ");
                }
                Console.WriteLine();
            }
            double prom = (temp[0,4] + temp[0,5] + temp[0,6]) / 3;
            Console.WriteLine("El promedio de los útlimos 3 días es "+prom);

            double temperaturamax = temp[0, 1];
            int Mascaluroso = 0;
            for (int i = 1; i < 7; i++)
            {
                if (temp[1, i] > temperaturamax)
                {
                    temperaturamax = temp[1, i];
                    Mascaluroso = i;
                }
            }
            Console.WriteLine("Día más caluroso por la tarde: {0} ({1} °)", Mascaluroso + 1, temperaturamax);

            double temperaturamin = temp[0, 0];
            int Masfrio = 0;
            for (int i = 1; i < 7; i++)
            {
                if (temp[0, i] < temperaturamin)
                {
                    temperaturamin = temp[0, i];
                    Masfrio = i;
                }
            }
            switch (Masfrio)
            {

                case 0:
                    Console.WriteLine("Lunes");
                    break;
                case 1:
                    Console.WriteLine("Martes");
                    break;
                case 2:
                    Console.WriteLine("Miércoles");
                    break;
                case 3:
                    Console.WriteLine("Jueves");
                    break;
                case 4:
                    Console.WriteLine("Viernes");
                    break;
                case 5:
                    Console.WriteLine("Sábado");
                    break;
                case 6:
                    Console.WriteLine("Domingo");
                    break;
            }
            Console.WriteLine("Día más frio {0} ({1} °)", Masfrio + 1, temperaturamin);

            double grados = temp[0, 0];
            int cont = 0;
            for (int i = 0; i < 7; i++)
            {
                if (temp[0, i] < 30)
                {
                    grados = temp[0, i];
                    cont++;
                }
            }
            Console.WriteLine("Los numeros menores a 30 grados en la mañana son:"  + cont);

            double grados2 = temp[0, 1];
            int cont2 = 0;
            for (int i = 0; i < 7; i++)
            {
                if (temp[1, i] < 30)
                {
                    grados2 = temp[1, i];
                    cont2++;
                }
            }
            Console.WriteLine("Los numeros menores a 30 grados en la tarde son:" + cont2);

            double promgeneral = (temp[0, 0] + temp[0, 1] + temp[0, 2] + temp[0, 3] + temp[0, 4] + temp[0, 5] + temp[0,6] + temp[1, 0] + temp[1, 1] + temp[1, 2] + temp[1, 3] + temp[1, 4] + temp[1, 5] + temp[1, 6]) / 14 ;
            Console.WriteLine("El promedio de la temporada es " + promgeneral);
            if (promgeneral > 30)
            {
                Console.WriteLine("Es temporada calurosa");
            }else
            {
                Console.WriteLine("No es temporada calurosa");
            }
            Console.ReadKey();
        }
    }
}
